package interfaces;

import dao.UsuarioDao;
import javax.swing.JOptionPane;
import model.Usuario;

public class TelaCadastro extends javax.swing.JFrame {

    public TelaCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCancelar = new javax.swing.JButton();
        lblSenhaCadastro = new javax.swing.JLabel();
        lblConfirmeCadastro = new javax.swing.JLabel();
        lblEmailCadastro = new javax.swing.JLabel();
        lblCelularCadastro = new javax.swing.JLabel();
        lblNomeCadastro = new javax.swing.JLabel();
        btnLimpar = new javax.swing.JButton();
        btnCadastrar = new javax.swing.JButton();
        txtEmail = new javax.swing.JTextField();
        txtCelular = new javax.swing.JTextField();
        txtConfirme = new javax.swing.JPasswordField();
        txtSenha = new javax.swing.JPasswordField();
        txtNome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnCancelar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(121, 94, 94));
        btnCancelar.setText("Cancelar");
        btnCancelar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 650, 150, 60));

        lblSenhaCadastro.setBackground(new java.awt.Color(0, 102, 0));
        lblSenhaCadastro.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        lblSenhaCadastro.setForeground(new java.awt.Color(110, 86, 86));
        lblSenhaCadastro.setText("Senha:");
        getContentPane().add(lblSenhaCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, 120, 60));

        lblConfirmeCadastro.setBackground(new java.awt.Color(0, 102, 0));
        lblConfirmeCadastro.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        lblConfirmeCadastro.setForeground(new java.awt.Color(110, 86, 86));
        lblConfirmeCadastro.setText("Confirme:");
        getContentPane().add(lblConfirmeCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, 160, 40));

        lblEmailCadastro.setBackground(new java.awt.Color(0, 102, 0));
        lblEmailCadastro.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        lblEmailCadastro.setForeground(new java.awt.Color(110, 86, 86));
        lblEmailCadastro.setText("Email:");
        getContentPane().add(lblEmailCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, 120, 60));

        lblCelularCadastro.setBackground(new java.awt.Color(0, 102, 0));
        lblCelularCadastro.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        lblCelularCadastro.setForeground(new java.awt.Color(110, 86, 86));
        lblCelularCadastro.setText("Celular:");
        getContentPane().add(lblCelularCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 280, 140, 50));

        lblNomeCadastro.setBackground(new java.awt.Color(0, 102, 0));
        lblNomeCadastro.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        lblNomeCadastro.setForeground(new java.awt.Color(110, 86, 86));
        lblNomeCadastro.setText("Nome:");
        getContentPane().add(lblNomeCadastro, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 120, 60));

        btnLimpar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        btnLimpar.setForeground(new java.awt.Color(105, 83, 83));
        btnLimpar.setText("Limpar");
        btnLimpar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLimpar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 580, 140, 60));

        btnCadastrar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        btnCadastrar.setForeground(new java.awt.Color(121, 94, 94));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 580, 170, 60));

        txtEmail.setFont(new java.awt.Font("Gill Sans MT Condensed", 0, 36)); // NOI18N
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 360, 320, 40));

        txtCelular.setFont(new java.awt.Font("Gill Sans MT Condensed", 0, 36)); // NOI18N
        getContentPane().add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 280, 320, 40));

        txtConfirme.setFont(new java.awt.Font("Gill Sans MT Condensed", 0, 36)); // NOI18N
        getContentPane().add(txtConfirme, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 500, 320, 40));

        txtSenha.setFont(new java.awt.Font("Gill Sans MT Condensed", 0, 36)); // NOI18N
        txtSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSenhaActionPerformed(evt);
            }
        });
        getContentPane().add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 430, 320, 40));

        txtNome.setFont(new java.awt.Font("Gill Sans MT Condensed", 0, 36)); // NOI18N
        getContentPane().add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 210, 320, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/interfaces/FotoCadastro.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSenhaActionPerformed
        
    }//GEN-LAST:event_txtSenhaActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        Usuario usuario = new Usuario();
        
        String nome, celular, email, senha, confirme;
        nome = (txtNome.getText());
        celular = (txtCelular.getText());
        email = (txtEmail.getText());
        senha = new String(txtSenha.getPassword());
        confirme = new String (txtConfirme.getPassword());
        if (nome.trim().equals("") || celular.trim().equals("")
        || email.trim().equals("") || senha.trim().equals("") || confirme.trim().equals("")){
            JOptionPane.showMessageDialog(rootPane, "Preencha todos os campos.");
        }
        else if (!senha.equals(confirme)){
        JOptionPane.showMessageDialog(rootPane, "A Senha não confere.");
    }
        else {
            usuario.setNome(txtNome.getText());
            usuario.setCelular(txtCelular.getText());
            usuario.setEmail(txtEmail.getText());
            usuario.setSenha(senha);
            UsuarioDao dao = new UsuarioDao();
            dao.adicionaUsuario(usuario);
            JOptionPane.showMessageDialog(rootPane, "Usuario cadastrado com sucesso!");

        TelaLogin telalogin = new TelaLogin();
        telalogin.setVisible(true);
        this.dispose();
    }  
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja sair do cadastro?");
        if (resposta == 0) {
        TelaLogin telalogin = new TelaLogin();
        telalogin.setVisible(true);
        this.dispose();
        }
        
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        txtNome.setText("");
        txtCelular.setText("");
        txtEmail.setText("");
        txtSenha.setText("");
        txtConfirme.setText("");

    }//GEN-LAST:event_btnLimparActionPerformed

    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblCelularCadastro;
    private javax.swing.JLabel lblConfirmeCadastro;
    private javax.swing.JLabel lblEmailCadastro;
    private javax.swing.JLabel lblNomeCadastro;
    private javax.swing.JLabel lblSenhaCadastro;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JPasswordField txtConfirme;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNome;
    private javax.swing.JPasswordField txtSenha;
    // End of variables declaration//GEN-END:variables
}
